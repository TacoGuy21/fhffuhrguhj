# 𝕊𝕝𝕒𝕥𝕖 𝕌𝕟𝕓𝕝𝕠𝕔𝕜𝕖𝕣
The 6th Unblocker in the greatsword series.
# 𝕎𝕙𝕒𝕥 𝕚𝕤 𝕊𝕝𝕒𝕥𝕖 𝕌𝕟𝕓𝕝𝕠𝕔𝕜𝕖𝕣?
Slate is an Unblocker made by Tacogamerman using Rhodium.
# 𝕆𝕦𝕣 𝕕𝕚𝕤𝕔𝕠𝕣𝕕

(https://discord.gg/BMxe6D9CKv)


![Discord](http://invidget.switchblade.xyz/BMxe6D9CKv)

# ℂ𝕣𝕖𝕕𝕚𝕥 

* Made with rhodium because im a lazy fuck

* Also because it is supposed to be similar to cosmic.

# 𝕊𝕙𝕠𝕨𝕔𝕒𝕤𝕖:
------
<img width="959" alt="image" src="https://github.com/Tacogamerman/Slate-Unblocker/assets/119009502/f75ed41e-271a-4af5-91d2-e292bd396cf2">

